package com.java.filecompare;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.io.File; 
import java.io.IOException; 

import org.apache.pdfbox.pdmodel.PDDocument; 
import org.apache.pdfbox.pdmodel.text.*;
//import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.PDFTextStripperByArea;
import org.apache.pdfbox.*;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import com.java.filecompare.DetailedReport;

import de.redsix.pdfcompare.CompareResult;
import de.redsix.pdfcompare.PdfComparator;



public class compareTextFile {
	/*
	public Thread t;
	public static String xlsName;
	public static String xlsPath;
	public static String sheetName;
	public int rowNum1;
	
	CompareXls(String xlsPath1,String xlsName1,String sheetName1)
	{	
		
		   xlsName=xlsName1;
		   xlsPath=xlsPath1;
		   sheetName=sheetName1;
	}
	
	*/
	//public static Hashtable htable=new Hashtable(); 
	//public static ArrayList<Hashtable<String,String>> exceldata  = new ArrayList<Hashtable<String,String>>();
	
    private static final String SheetName = null;
	private static final String String = null;


	public static List< String> readTextfile(String filePathName) throws IOException  
    {
     
		
		List<String> exceldata  = new ArrayList<String>();
		exceldata.clear();
   
        try 
        {   
        	BufferedReader file = new BufferedReader(new FileReader(filePathName));
            String str;
            int j=0;
            while ((str = file.readLine()) != null) {
            	exceldata.add(j,str);
                System.out.println(str);
                j++;
            }
            System.out.println(str);

      } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
        
        return exceldata;     
    }
	
	public static List< String> readPDFfile(String filePathName) throws IOException  
    {
		
		List<String> exceldataPDF  = new ArrayList<String>();
		exceldataPDF.clear();
   
        try 
        {   

            PDDocument document1 = null;
    	    document1 = PDDocument.load(new File(filePathName));
    	    document1.getClass();
    	    if (!document1.isEncrypted()) {
    	        PDFTextStripperByArea stripper = new PDFTextStripperByArea();
    	        stripper.setSortByPosition(true);
    	        PDFTextStripper Tstripper = new PDFTextStripper();
    	        String st1 = Tstripper.getText(document1);
    	        //System.out.println("Text:" + st);
    	        String[] lines = st1.split("\n");
    	        int b=0;
    	        for (String line : lines) {
                	exceldataPDF.add(b,line);

    	           System.out.println(b +"Text:" +line);
    	           b++;
    	        }
    	    }
        }
        catch (IOException e) 
        {
            e.printStackTrace();
        }
        
        return exceldataPDF;     
    }

    
    public static void CompareFile(String SourceFile,String TargetFile,String ResultLogPath,String FileType) throws FileNotFoundException
    {
    	int TrCount;
		int SoCount;
	    List<String> Trexceldata1  = new ArrayList<String>();
	    List<String> Soexceldata6  = new ArrayList<String>();
	    String[] ResultLogs = new String[1000];
	    ArrayList<String> Rlog = new ArrayList<String>();
	    DetailedReport DRobj =new DetailedReport();
	    String PdfResult=null;
	    
	      Date dNow = new Date( );
	      SimpleDateFormat ft = new SimpleDateFormat ("YYYY_MM_dd_hh_mm");


	    
	    String FieldNames = "",RwoNum = "";
	    String FActual = null;
	    boolean flag1=false;

		try {
			if (FileType.toUpperCase().equals("TXT")){
				Soexceldata6=readTextfile(SourceFile);	
				Trexceldata1=readTextfile(TargetFile);
				DRobj.PageTitleheadings("Compare TXT file");
			}
			else{
				
				Soexceldata6=readPDFfile(SourceFile);	
				Trexceldata1=readPDFfile(TargetFile);
				DRobj.PageTitleheadings("Compare PDF file");
				final CompareResult result = new PdfComparator(SourceFile, TargetFile).compare();
				
				if (result.isNotEqual()) {
				    System.out.println("Differences found!");
				    String ResultfPDFfleName=ft.format(dNow)+"_Result";
				    PdfResult=ResultLogPath + ResultfPDFfleName;
				    result.writeTo(PdfResult);
				    
				}
				if (result.isEqual()) {
				    System.out.println("No Differences found!");
				   
				}
				if (result.hasDifferenceInExclusion()) {
				    System.out.println("Only Differences in excluded areas found!");
				}
			}

			TrCount=Trexceldata1.size();
			SoCount=Soexceldata6.size();
			
			
			Rlog.add(0, "Source "+ FileType.toUpperCase() + " File: "+ SourceFile);
			
			DRobj.createRow();
			DRobj.headings("Source "+ FileType.toUpperCase() + " File: ");
			DRobj.infoStatements(SourceFile);
			DRobj.infoStatements("");
			if (FileType.toUpperCase().equals("PDF"))
			{
			DRobj.hperlinkStatements(PdfResult + ".pdf");
			}
			DRobj.endRow();
			
			Rlog.add(1, "Target "+ FileType.toUpperCase() + " File: "+ TargetFile);
			
			DRobj.createRow();
			DRobj.headings("Target "+ FileType.toUpperCase() + " File: ");
			DRobj.infoStatements(TargetFile);
			DRobj.infoStatements("");
			DRobj.infoStatements("");
			DRobj.endRow();
			
			DRobj.createRow();
			DRobj.headings("Record Number");
			DRobj.headings("Umatch Row number:");
			DRobj.headings("Expected Data");
			DRobj.headings("Actual Data");
			DRobj.endRow();
			
			
			int trgCount;
			
			if (TrCount > SoCount){
				trgCount=SoCount;
			}
			else{
				trgCount=TrCount;
			}
			
			int a=2;
			
			for(int i=0;trgCount>i;i++)

		     {
				String SoHash=Soexceldata6.get(i).trim();
				String TrHash=Trexceldata1.get(i).trim();

	                if (SoHash.equals(TrHash)){
	                   //System.out.println("Match :" + i);
	                	flag1=false;
	                  }else{
	                	RwoNum=Integer.toString(i+1);
	                	FieldNames=FieldNames+ "|"+ TrHash;
	                	flag1=true;
	                }
                
                
                if(flag1==true) {

                 Rlog.add(a,"Row number |"+ RwoNum  +"| Umatch Row Data |"+ FieldNames + "|");
                 DRobj.createRow();
                 DRobj.failStatements(a-1 +"");
                 DRobj.failStatements(RwoNum);
                 DRobj.failStatements(TrHash);
                 DRobj.failStatements(SoHash);
                 DRobj.endRow();
                 a++;
                 flag1=false;
                 FieldNames="";
            
                }
                
		     }//For Loop Ends
			
		    String ResultfileNameS=ft.format(dNow)+"_Result.txt";
		    BufferedWriter bw = new BufferedWriter(new FileWriter(ResultLogPath + ResultfileNameS, true)); 
            int d=0;
			for(int k=0;Rlog.size()>k; k++){

				if (Rlog.get(k)!=null)
				{
					
					//if (k>=2)DRobj.failStatements(Rlog.get(k));
					d++;
					bw.write(Rlog.get(k));
					bw.newLine();
					bw.flush();	
				}else if(Rlog.get(k)==null && Rlog.size()>=k){
					bw.write("All Recored Match");
					DRobj.createRow();
					DRobj.passStatements("All Recored Match");
					bw.newLine();
					bw.flush();					
				}
				
			}
			
			DRobj.setErrorCount(d-2);
			DRobj.create_HTML("Comapre Report");
			 
			//outputStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		catch (NullPointerException d) {
			// TODO Auto-generated catch block
			d.printStackTrace();
			System.out.println(d.getMessage());
		}finally
		{//	System.getProperty("user.dir")
			Trexceldata1.clear();
			Soexceldata6.clear();
			Rlog.clear();
    	}
	   
    }



}
