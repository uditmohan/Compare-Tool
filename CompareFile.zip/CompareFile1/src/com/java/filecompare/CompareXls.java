package com.java.filecompare;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

import org.apache.poi.xssf.usermodel.*;

public class CompareXls {
	
    private static final String SheetName = null;
	private static final String String = null;


	//@SuppressWarnings("resource")
	public static List<Hashtable<String, String>> readexcel(String xlsPathName,String sheetName) throws IOException  
    {
     
    List<Hashtable<String,String>> exceldata  = new ArrayList<Hashtable<String,String>>();

    FileInputStream file1 = new FileInputStream(new File(xlsPathName));

	XSSFCell  firstrowelement = null;  
  
        try 
        {   
        	XSSFWorkbook w = new XSSFWorkbook(file1); 
        	XSSFSheet sheet = w.getSheet(sheetName); 

            for (int j = 0; j <=sheet.getLastRowNum(); j++) 
            {   
            	Hashtable htable=new Hashtable();
                for (int i = 0; i < sheet.getRow(j).getLastCellNum(); i++) 
                {       	
                    firstrowelement = sheet.getRow(0).getCell(i);
                    if (j!=0)
                    {
	                    XSSFCell cell = sheet.getRow(j).getCell(i);
	                try {
	                    htable.put(firstrowelement.getStringCellValue(),cell.getNumericCellValue());                
	                    } 
	                catch(IllegalStateException e)
	                    {
	                    htable.put(firstrowelement.getStringCellValue(),cell.getStringCellValue()); 
	                    }
                    }
                }
                exceldata.add(j,htable);
            }
            w.close();
      } 
        catch (IOException e) 
        {
            //e.printStackTrace();
            e.printStackTrace(new PrintStream(new FileOutputStream("error.log")));
        }
        catch (NullPointerException d) {
			// TODO Auto-generated catch block
			//d.printStackTrace();
			d.printStackTrace(new PrintStream(new FileOutputStream("error.log")));
			//System.out.println(d.getMessage());
		}
           return exceldata;
           
    }

    
    public static void CompareExcel(String SourceFile,String TargetFile,String SheetName,String ResultLogPath) throws FileNotFoundException
    {
    	int TrCount;
		int SoCount;
	    List<Hashtable<String,String>> Trexceldata1  = new ArrayList<Hashtable<String,String>>();
	    List<Hashtable<String,String>> Soexceldata6  = new ArrayList<Hashtable<String,String>>();
	    String[] ResultLogs = new String[1000];
	    ArrayList<String> Rlog = new ArrayList<String>();
	    DetailedReport DRobj =new DetailedReport();
	    DRobj.PageTitleheadings("Compare XlS file");
	    
	    String FieldNames = "",RwoNum = "";
	    boolean flag1=false;

		try {
			
			Soexceldata6=readexcel(SourceFile,SheetName);	
			Trexceldata1=readexcel(TargetFile,SheetName);

			TrCount=Trexceldata1.size();
			SoCount=Soexceldata6.size();
			
			Rlog.add(0, "Source Excel File: "+ SourceFile);
			DRobj.createRow();
			DRobj.headings("Source Excel File:");
			DRobj.infoStatements(SourceFile);
			DRobj.infoStatements("Number of Row:"+SoCount);
			DRobj.endRow();
			
			Rlog.add(1, "Target Excel File: "+ TargetFile);
			DRobj.createRow();
			DRobj.headings("Target Excel File:");
			DRobj.infoStatements(SourceFile);
			DRobj.infoStatements("Number of Row:"+TrCount);
			DRobj.endRow();
			
			Rlog.add(2, "WorkSheet for Compare: "+ SheetName);
			DRobj.createRow();
			DRobj.headings("WorkSheet for Compare: ");
			DRobj.infoStatements(SheetName);
			DRobj.infoStatements("");
			DRobj.endRow();
			
			DRobj.createRow();
			DRobj.headings("Record Number");
			DRobj.headings("Umatch Row number:");
			DRobj.headings("Umatch Columns");
			DRobj.endRow();

			int lessCount;
			
			if (TrCount > SoCount){
				lessCount=SoCount;
			}
			else{
				lessCount=TrCount;
			}
	
			int a=3;
			for(int i=0;lessCount>i;i++)

		     {
				Hashtable SoHash=Soexceldata6.get(i);
				Hashtable TrHash=Trexceldata1.get(i);
				
				Enumeration e = SoHash.keys();

                while (e.hasMoreElements()) {
	                String key = (String) e.nextElement();
	                if (SoHash.get(key).equals(TrHash.get(key))){
	                   //System.out.println("Match :" + i);
	                  }else{
	                	RwoNum=Integer.toString(i+1);
	                	FieldNames=FieldNames+ "|| " + key;
	                	flag1=true;
	                }

                }//While Loop Ends
  
                if(flag1==true) {

                 Rlog.add(a,"Row number : "+ RwoNum  +" Umatch Fields "+ FieldNames + "|");
                 
                 DRobj.createRow();
                 DRobj.failStatements(a-2 +"");
                 DRobj.failStatements(RwoNum);
                 DRobj.failStatements(FieldNames +"||");
                 DRobj.endRow();
                 
                 a++;
                 flag1=false;
                 FieldNames="";
                }
                
		     }
    			if (TrCount > SoCount){   
    				for(int j=lessCount;TrCount>j;j++){
    					Hashtable TrHash1=Trexceldata1.get(j);
    					Enumeration e1 = TrHash1.keys();
    	                while (e1.hasMoreElements()) {
    		                    String key = (String) e1.nextElement();
    		                	RwoNum=Integer.toString(j+1);
    		                	FieldNames=FieldNames+ "|| " + key;
    		                }
    					 Rlog.add(a,"Row number : "+ RwoNum  +" Umatch Fields "+ FieldNames + "|");
       	                 DRobj.createRow();
       	                 DRobj.failStatements(a-2 +"");
       	                 DRobj.failStatements(RwoNum);
       	                 DRobj.failStatements(FieldNames +"||");
       	                 DRobj.endRow();
       					 a++;
       					 FieldNames="";
       				}
    			}
    			else{
    				for(int j=lessCount;SoCount>j;j++){
    				Hashtable SoHash1=Soexceldata6.get(j);
					Enumeration e1 = SoHash1.keys();
	                  while (e1.hasMoreElements()) {
		                    String key = (String) e1.nextElement();
		                	RwoNum=Integer.toString(j+1);
		                	FieldNames=FieldNames+ "|| " + key;
		                }
   					 Rlog.add(a,"Row number : "+ RwoNum  +" Umatch Fields "+ FieldNames + "|");
   					 
   	                 DRobj.createRow();
   	                 DRobj.failStatements(a-2 +"");
   	                 DRobj.failStatements(RwoNum);
   	                 DRobj.failStatements(FieldNames +"||");
   	                 DRobj.endRow();
   					 a++;
   					 FieldNames="";
   				     }
    			}    
			
		      Date dNow = new Date( );
		      SimpleDateFormat ft = new SimpleDateFormat ("YYYY_MM_dd_hh_mm");
		      String ResultfileNameS=ft.format(dNow)+"_"+SheetName+"_Result.txt";
		      BufferedWriter bw = new BufferedWriter(new FileWriter(ResultLogPath +SheetName+ ResultfileNameS, true)); 
		    
		      int d=0;  
			//System.out.println(ResultLogs.length);
			for(int k=0;Rlog.size()>k; k++){

				if (Rlog.get(k)!=null)
				{
					bw.write(Rlog.get(k));
					bw.newLine();
					bw.flush();
					d++;
				}else if(Rlog.get(k)==null && Rlog.size()>=k){
	                DRobj.createRow();
	                DRobj.passStatements("0");
	                DRobj.passStatements("0");
	                DRobj.passStatements("All Recored Match");
	                DRobj.endRow();
					bw.write("All Recored Match");
					bw.newLine();
					bw.flush();					
				}
				
			}
	   
			DRobj.setErrorCount(d-2);
			DRobj.create_HTML("Comapre Report");
			//outputStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			e.printStackTrace(new PrintStream(new FileOutputStream("error.log")));
			//System.out.println(e.getMessage());
		}
		catch (NullPointerException d) {
			// TODO Auto-generated catch block
			//d.printStackTrace();
			d.printStackTrace(new PrintStream(new FileOutputStream("error.log")));
			//System.out.println(d.getMessage());
		}finally
		{//	System.getProperty("user.dir")
			Trexceldata1.clear();
			Soexceldata6.clear();
			Rlog.clear();
    	}
	   
    }


}
