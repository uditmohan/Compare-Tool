package com.java.filecompare;


import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.*;

import javax.imageio.ImageIO;

import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.WritableRaster;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ImageCompar
{

	public static void CompareFileImage(String SourceFile,String TargetFile,String ResultLogPath,String FileType) throws FileNotFoundException,IOException


{
    long start = System.currentTimeMillis();
    int q=0;
    File file1 = new File(ResultLogPath + "/filename.txt");
    DetailedReport DRobj =new DetailedReport();
    DRobj.PageTitleheadings("Compare Image file");


    FileWriter fw = new FileWriter(file1.getAbsoluteFile());
    BufferedWriter bw = new BufferedWriter(fw);

    File file= new File(SourceFile);//"/Users/vikramsdev/Desktop/MyAllDocs/CompareFile/Regina1.jpeg");
    BufferedImage image = ImageIO.read(file);
    
    int width = image.getWidth(null);
    int height = image.getHeight(null);
	int[][] clr=  new int[width][height];
		    
	File files= new File(TargetFile); //"/Users/vikramsdev/Desktop/MyAllDocs/CompareFile/Regina2.jpeg");
	BufferedImage images = ImageIO.read(files);
		    
	int widthe = images.getWidth(null);
	int heighte = images.getHeight(null);
	int[][] clre=  new int[widthe][heighte]; 
	
	Color myWhite = new Color(255, 0, 0); // Color white
	int rgb = myWhite.getRGB();
	
	int smw=0;
	int smh=0;
	int p=0;
	
	DRobj.createRow();
	DRobj.headings("Source Image File: ");
	DRobj.infoStatements(SourceFile);
	//DRobj.infoStatements("");
	DRobj.endRow();
	
	
	DRobj.createRow();
	DRobj.headings("Target Image File: ");
	DRobj.infoStatements(TargetFile);
	//DRobj.infoStatements();
	DRobj.endRow();
	
	DRobj.createRow();
	DRobj.headings("Indicators of verification");
	DRobj.headings("Statistcs Details");
	DRobj.endRow();
		    
        //CALUCLATING THE SMALLEST VALUE AMONG WIDTH AND HEIGHT
        if(width>widthe)
        { 
            smw =widthe;
        }
        else 
        {
            smw=width;
        }
        if(height>heighte)
        {
            smh=heighte;
        }
        else 
        {
            smh=height;
        }
        //CHECKING NUMBER OF PIXELS SIMILARITY
        BufferedImage cp;
        cp = deepCopy(image,ResultLogPath);
        for(int a=0;a<smw;a++)
        {
            for(int b=0;b<smh;b++)
            {
                clre[a][b]=images.getRGB(a,b);
                clr[a][b]=image.getRGB(a,b);
               
                if(clr[a][b]==clre[a][b]) 
                {
                	p=p+1;
                    bw.write("\t");
                     bw.write(Integer.toString(a));
                    bw.write("\t");
                     bw.write(Integer.toString(b)); 
                    bw.write("\n");
                }
                else
                {
                    q=q+1;
                    cp.setRGB(a, b, rgb);
                }
            }
        }
        Date dNow = new Date( );
        String PdfResult=null;
	    SimpleDateFormat ft = new SimpleDateFormat("YYYY_MM_dd_hh_mm");
	    PdfResult=ResultLogPath+"/"+ft.format(dNow)+"_ResultFile1.png";
        File outputfile = new File(PdfResult);
        ImageIO.write(cp, "png", outputfile);

float w,h=0;
if(width>widthe) 
{
    w=width;
}
else 
{
    w=widthe;
}
if(height>heighte)
{ 
    h = height;
}
else
{
    h = heighte;
}
float s = (smw*smh);
//CALUCLATING PERCENTAGE
float x =(100*p)/s;

DRobj.createRow();
DRobj.infoStatements("THE PERCENTAGE SIMILARITY IS APPROXIMATELY:-");
DRobj.infoStatements(x+"%");
DRobj.endRow();
long stop = System.currentTimeMillis();

DRobj.createRow();
DRobj.infoStatements("TIME TAKEN IS:-");
DRobj.infoStatements(""+ (stop-start));
DRobj.endRow();

DRobj.createRow();
DRobj.infoStatements("NO OF PIXEL GETS UNMATCHED:-");
DRobj.infoStatements(""+ (q));
DRobj.endRow();

DRobj.createRow();
DRobj.infoStatements("NO OF PIXEL GETS MATCHED:-");
DRobj.infoStatements(""+ (p));
DRobj.endRow();

DRobj.createRow();
DRobj.infoStatements("Hyperlink for Result Image:-");
DRobj.hperlinkStatements(PdfResult);
DRobj.endRow();

DRobj.setErrorCount(q);
DRobj.create_HTML("Comapre Report");

System.out.println("THE PERCENTAGE SIMILARITY IS APPROXIMATELY ="+x+"%");

System.out.println("TIME TAKEN IS ="+(stop-start));
System.out.println("NO OF PIXEL GETS UNMATCHED:="+q);
System.out.println("NO OF PIXEL GETS MATCHED:="+p);

}
	
static BufferedImage deepCopy(BufferedImage bi,String Resultpath) throws IOException {
        String saveAs = "copy.jpg";
        ColorModel cm = bi.getColorModel();
        boolean isAlphaPremultiplied = cm.isAlphaPremultiplied();
        WritableRaster raster = bi.copyData(null);
        BufferedImage cImg = new BufferedImage(cm, raster, isAlphaPremultiplied, null);
        File saveImage = new File(Resultpath+"/", saveAs);
        ImageIO.write(cImg, "jpg", saveImage);
        return cImg;
}
}
