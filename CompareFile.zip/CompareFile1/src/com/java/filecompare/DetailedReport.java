package com.java.filecompare;


import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

public class DetailedReport {

               private static volatile String reportPathWithTimeStamp;
               protected int fail = 0;
               protected int counter = 0;
               private String body = "";
               private int errors = 0;

              
               public DetailedReport(){
                              
               }

               public  String getReportPath() throws IOException {

                               if(reportPathWithTimeStamp == null) {
				                           		Properties prop = new Properties();
				                        		InputStream input = new FileInputStream("config.properties");
				                        		prop.load(input);
				                        		String ResultLogPath=prop.getProperty("ResultLogPath");

                                               if(ResultLogPath.equals(null)) {
                                            	   System.out.println("relativePath is not set!");
                                                  }

                                               reportPathWithTimeStamp =ResultLogPath;

                               }

                               return reportPathWithTimeStamp;
               }

               public String getCurrentFormattedTime(String dateFormatString) {
                               DateFormat dateFormat = new SimpleDateFormat(dateFormatString);
                               Calendar calendar = Calendar.getInstance();
                               return dateFormat.format(calendar.getTime());
               }
              
public void create_HTML (String reportName) {
      
       try {
               
		   Date dNow = new Date( );
		   SimpleDateFormat ft = new SimpleDateFormat ("YYYY_MM_dd_hh_mm");
		   String ResultfileNameS=ft.format(dNow)+"DetailReport.html";
           System.out.println(ResultfileNameS);
          // File file = new File(getReportPath());
           File file = new File(getReportPath());
           if (!file.exists())file.mkdir();
           OutputStream htmlfile = new FileOutputStream(new File(file +"/"+ ResultfileNameS));
           PrintStream printhtml = new PrintStream(htmlfile);
              
           String temp = "";
              
           String htmlheader="<html><h1 align =\"center\"  background-color:\"#DAA520\">File Compare Report</h1><head>";
           htmlheader+="<title>File Compare Report HTML</title><style type=\"text/css\">#maintable {  width: 800px;  margin: 0 auto; }</style>";
           htmlheader+="<style>body {background-color:lightgrey}</style>";
           htmlheader+="</head><body>";
           String htmlfooter="</table></body></html>";
          
           temp = htmlheader;
           temp += "<table border=\"1\" style=\"width:100%\" id=\"maintable\">";
//           temp += "<tr><th bgcolor = \"#FCF3CF\" style= \"color:red\">Total Number of Errors : </th><th bgcolor = \"#FCF3CF\" style= \"color:red\">"+String.valueOf(fail/2)+"</th></tr>";
           temp += "<tr> <th bgcolor = \"#FCF3CF\" style= \"color:red\">Total Missmatch Count : </th><th bgcolor = \"#FCF3CF\" style= \"color:red\">"+getErrorcount()+"</th></tr>";
           temp += body;
           temp += htmlfooter;
           printhtml.println(temp);
              
                       printhtml.close();
                       htmlfile.close();
                       File htmlFile = new File(file +"/"+ ResultfileNameS);

                      
       } catch (Exception pce) {
               pce.printStackTrace();
       }
               }

               public void headings(String text) {
                      
                                body += "<th bgcolor = \"#00E5EE\">" + text + "</th>";
               }
              
                public void PageTitleheadings(String text) {
                	
                	body += "<html><h2 align =\"center\">"+text +"</h2><head>";                      
                                
               }
              
               public void passStatements(String text) {
                      
                                body += "<td bgcolor = \"#58D68D\">" + text + "</td>";
               }
              
               public void infoStatements(String text) {
                      
                                body += "<td bgcolor = \"#DAA520\">" + text + "</td>";
               }
              
                public void failStatements(String text) {
                    
                                body += "<td bgcolor = \"#F1948A\">" + text + "</td>";
                               fail++;
               }
                public void hperlinkStatements(String text) {
                    
                    body += "<td bgcolor = \"#58D68D\"> <a href=" + text +">OUTPUT file with differences</a> </td>";
                   
                }
                public void warningStatements(String text) {
                              
                                body += "<td bgcolor = \"#F0E68C\">" + text + "</td>";
                      
                }
               public void createRow() {
                      
                                body += "<tr>";
               }
              
               public void endRow() {
                      
                                body += "</tr>";
               }
              
                public int getErrorcount()
               {
                               return errors;
               }
              
                public void setErrorCount(int cnt){
                              
                                errors +=cnt;
               }




}
