package com.java.filecompare;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.*;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.util.PageExtractor;
import org.apache.pdfbox.tools.ExtractImages;

public class PDFImageRead {
	public static void main(String args[]) throws IOException {

	      //Loading an existing PDF document
	      File file = new File("/Users/vikramsdev/Desktop/MyAllDocs/CompareFile/passport2.pdf");
	      PDDocument document = PDDocument.load(file);
	      PDPageTree doc = document.getPages();
	      System.out.println(doc.getCount());
	      
	      //PageExtractor pdfpage= new PageExtractor(document);
	      //System.out.println(pdfpage.extract());
	      
	      //Instantiating the PDFRenderer class
	      PDFRenderer renderer = new PDFRenderer(document);
	      //ExtractImages getimg=new tools();

	      //Rendering an image from the PDF document
	      BufferedImage image = renderer.renderImage(0);

	      //Writing the image to a file
	      ImageIO.write(image, "JPEG", new File("/Users/vikramsdev/Desktop/MyAllDocs/CompareFile/myimage.jpg"));
	       
	      System.out.println("Image created");
	       
	      //Closing the document
	      document.close();

	   }
}
