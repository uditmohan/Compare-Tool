package com.java.filecompare;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument; 
import org.apache.pdfbox.pdmodel.text.*;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.PDFTextStripperByArea;
import org.apache.pdfbox.*;

import de.redsix.pdfcompare.CompareResult;
import de.redsix.pdfcompare.PdfComparator;


public class readPDF {

	public static void main(String args[]) throws InterruptedException, IOException {
	     
	try {
		
		final CompareResult result = new PdfComparator("/Users/vikramsdev/Desktop/MyAllDocs/CompareFile/myfile copy1.pdf", "/Users/vikramsdev/Desktop/MyAllDocs/CompareFile/myfile copy2.pdf").compare();
		if (result.isNotEqual()) {
		    System.out.println("Differences found!");
		    result.writeTo("/Users/vikramsdev/Desktop/MyAllDocs/CompareFile/comparefiler.pdf");
		}
		if (result.isEqual()) {
		    System.out.println("No Differences found!");
		   
		}
		if (result.hasDifferenceInExclusion()) {
		    System.out.println("Only Differences in excluded areas found!");
		}
	    /*PDDocument document = null;
	    document = PDDocument.load(new File("/Users/vikramsdev/Desktop/myfile June 30.pdf"));
	    document.getClass();
	    if (!document.isEncrypted()) {
	        PDFTextStripperByArea stripper = new PDFTextStripperByArea();
	        stripper.setSortByPosition(true);
	        PDFTextStripper Tstripper = new PDFTextStripper();
	        String st = Tstripper.getText(document);
	        System.out.println("Text:" + st);
	        String[] lines = st.split("\\r?\\n");
	        int a=0;
	        for (String line : lines) {
	           
	           System.out.println(a +"Text:" +line);
	           a=a+1;
	        }
	    }*/
	} catch (Exception e) {
	    e.printStackTrace();
	}
}

}
