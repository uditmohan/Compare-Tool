package com.java.filecompare;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import com.java.filecompare.*;
//import com.java.xlstest.CompareXls;

public class CompareExecute {

	public static void main(String args[]) throws InterruptedException, IOException {
	     
		try
		{
			
		System.setErr(new PrintStream(new FileOutputStream(System.getProperty("user.home")+"/error.log")));
		Properties prop = new Properties();
		InputStream input = new FileInputStream("config.properties");
		prop.load(input);
		// get the property value and print it out 
		//Thread.sleep(20000);
		String SourceFile=prop.getProperty("SourceFilePath");//"/Users/atsclab/Desktop/Automation_tools/Projects/Employee1.xlsx";
		String TargetFile=prop.getProperty("TargetFilePath");//"/Users/atsclab/Desktop/Automation_tools/Projects/Employee2.xlsx";	
		String ResultLogPath=prop.getProperty("ResultLogPath");//"/Users/atsclab/Desktop/Automation_tools/Projects/";
		String FileType=prop.getProperty("FileType");

		if(FileType.toUpperCase().equals("XLS"))
		{
			String[] SheetName=prop.getProperty("TargetSheetName").split(":");//"Employee_Data";
			
			for (int i=0;i<SheetName.length;i++)
			{
			CompareXls cm1=new CompareXls();		
			cm1.CompareExcel(SourceFile, TargetFile, SheetName[i], ResultLogPath);
		}
		}
		else if(FileType.toUpperCase().equals("IMG"))
		{
			ImageCompar Icm=new ImageCompar();		
			Icm.CompareFileImage(SourceFile, TargetFile, ResultLogPath,FileType);	
		}
		else
		{
			compareTextFile cm=new compareTextFile();		
			cm.CompareFile(SourceFile, TargetFile, ResultLogPath,FileType);
			
		}
		
		} catch(FileNotFoundException ex){
			ex.printStackTrace(new PrintStream(new FileOutputStream("error.log")));
		}catch(IOException ex){
			ex.printStackTrace(new PrintStream(new FileOutputStream("error.log")));	 
		}catch (Exception ex) {
			ex.printStackTrace(new PrintStream(new FileOutputStream("error.log")));
		}
		
	   }

	private static void Elseif(boolean equals) {
		// TODO Auto-generated method stub
		
	}   

}
